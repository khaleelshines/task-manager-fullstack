const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// In-memory task store
let tasks = [];
let idCounter = 1;

// Create Task
app.post('/tasks', (req, res) => {
    const { title, description } = req.body;
    const newTask = { id: idCounter++, title, description, completed: false };
    tasks.push(newTask);
    res.status(201).json(newTask);
});

// Get Tasks
app.get('/tasks', (req, res) => {
    res.json(tasks);
});

// Update Task
app.put('/tasks/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const { title, description, completed } = req.body;

    const task = tasks.find(t => t.id === id);
    if (!task) {
        return res.status(404).json({ message: 'Task not found' });
    }

    task.title = title !== undefined ? title : task.title;
    task.description = description !== undefined ? description : task.description;
    task.completed = completed !== undefined ? completed : task.completed;

    res.json(task); // Immediately respond to the client

    // Asynchronous notification simulation
    sendNotification(task)
        .then(() => console.log(`Notification sent for Task ID: ${task.id}`))
        .catch(err => console.error('Notification error:', err));
});

// Delete Task
app.delete('/tasks/:id', (req, res) => {
    const id = parseInt(req.params.id);
    tasks = tasks.filter(t => t.id !== id);
    res.json({ message: `Task ${id} deleted` });
});

// Mock asynchronous notification function
async function sendNotification(task) {
    return new Promise(resolve => {
        setTimeout(() => {
            console.log(`Task "${task.title}" updated.`);
            resolve();
        }, 2000); 
    });
}

// Start the server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
