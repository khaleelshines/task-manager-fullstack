import { Routes } from '@angular/router';
import { Tasks } from './components/tasks/tasks';

export const routes: Routes = [
    { path: '', component: Tasks }
];
