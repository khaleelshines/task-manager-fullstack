import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { combineLatest, map, Observable, of } from 'rxjs';
export interface Task {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}
@Injectable({
  providedIn: 'root'
})

export class Task {

  private apiUrl = 'http://localhost:3000/tasks';

  constructor(private http: HttpClient) {}

  getTasks(): Observable<Task[]> {
    return this.http.get<Task[]>(this.apiUrl);
  }

  createTask(task: Partial<Task>): Observable<Task> {
    return this.http.post<Task>(this.apiUrl, task);
  }

  updateTask(id: number, task: Partial<Task>): Observable<Task> {
    return this.http.put<Task>(`${this.apiUrl}/${id}`, task);
  }

  deleteTask(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  /**
   * RxJS requirement:
   * Merges backend tasks with local dummy priorities and filters out completed tasks.
   */
  getTasksWithPriority(): Observable<{ task: Task, priority: string }[]> {
    const priorities$ = of([
      { id: 1, priority: 'High' },
      { id: 2, priority: 'Medium' },
      { id: 3, priority: 'Low' }
    ]);

    return combineLatest([this.getTasks(), priorities$]).pipe(
      map(([tasks, priorities]) =>
        tasks.map(task => ({
          task,
          priority: priorities.find(p => p.id === task.id)?.priority || 'Normal'
        }))
      ),
      map(taskPriorityArray => taskPriorityArray.filter(tp => !tp.task.completed)) // filter out completed
    );
  }
}
