import { Component, OnInit } from '@angular/core';
import { Task } from '../../services/task'; // Assuming Task is an interface and TaskService is the service
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-tasks',
  imports: [CommonModule, FormsModule],
  templateUrl: './tasks.html',
  styleUrl: './tasks.css',
  standalone: true
})
export class Tasks implements OnInit {

  newTaskTitle = '';
  newTaskDescription = '';
  tasksWithPriority$: any;

  constructor(private taskService: Task) {
    // Initialize the task service
    this.tasksWithPriority$ = this.taskService.getTasksWithPriority();
  }

  ngOnInit(): void {
    this.refresh();
  }

  createTask() {
    if (!this.newTaskTitle) return;
    this.taskService.createTask({
      title: this.newTaskTitle,
      description: this.newTaskDescription
    }).subscribe(() => {
      this.refresh();
      this.newTaskTitle = '';
      this.newTaskDescription = '';
    });
  }

  updateTask(task: Task) {
    this.taskService.updateTask(task.id, { completed: !task.completed })
      .subscribe(() => this.refresh());
  }

  deleteTask(task: Task) {
    this.taskService.deleteTask(task.id)
      .subscribe(() => this.refresh());
  }

  refresh() {
    this.tasksWithPriority$ = this.taskService.getTasksWithPriority();
  }
}
